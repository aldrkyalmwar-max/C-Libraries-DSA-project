========================================================================================================================
                    ***** Module 1 _ ARRAYS ***** 
=================Part A — 1D Static Arrays=================
# function : initArray
## problem analysis and example : 
- input : arr[],*size 
- output : size =0 
- example : let us say we have a arr[100] , we used privously {-11, 6 , 90} 3 element , when we call our funtion it just set the size of the used array to 0 wich will make {-11, 6 , 90} ignored.
### algorithm : 
1. The function sets size to 0 
2. making all previous elements inaccessible 
3. and without modifying the actual memory
# function : printArray
## problem analysis and example :
- input : arr [], size 
- output : the array elements in a [a,b,c...]fotmat 

- example : let us say we have arr[100] ,the size is 5 , the elements are {12,32,45,87,9},this function will display the elent like that : [12,32,45,87,9].

### algorithm :
1. print [ .
2. then star printing the element of our array "arr[i]" (such that 0<= i  < size ).
3. after that if 0< i < size-1 print , .
4. after all elent are printed print ] .
# function : insertAt
## problem analysis and example : 
- input : arr[],* size, index, value
- output : an array with the new element in its spesific place
- example : let us say that our array is like this [12,0,5,9,-4] and i want to add 6 in 3rd place i will call the fuction and it will add 6 to the 3rd place and our array will be like that [12,0,6,5,9,-4] and our array has increced in size by one element.
### algorithm :
1. check if the index and the size is valid if it is not it will return -1 .
2. then it will make a place for the new element by shifting all the values before it .
3. then it will add the element in its sprsific place and increasing the size by 1 .
# function : deleteAt
## problem analysis and example :
- input : arr[], size, index,i
- output : the input array but with the element of the index deleted
- exaple : let us say that our array is like this [15,25,35,10,5] i give it the index 2 to delete it the array will be like that [15,25,10,5] the element onthe index 2 has been deleted and the size of the array has decresed by 1
### algorithm :
1. first it will check if the giving index is valid if it is not it will return -1 .
2. from our index to the rest of array it will replace each element by the one after it
3. in the last it will decrese the saze of array
# function : linearSearch
## problem analysis and example :
- input : arr[], size, value,i
- output : the position of the element 
- example : let us say that this is my array [4,7,91,8,-12,6] i use this function to know the position of the element 8 it will return me the position 3
### algorithm :
1. it will search for the element in all of the array .
2. if it finds it it will return the position .
3. else it will return -1.
# function : binarySearch
## problem analysis and example :
- input : arr[], size, value,mid,low,high
- output : position of a certain value in a sorted array  
- exaple : let us say that we have an array [12,34,56,78,90] (it need to be sorted) we wanna know the position of 56 so it will do the calculation of the middle by mid= (low+high) /2 mid in our case is 2 we check arr[2] is equal 56 so it will returns us 2 which is the positon in other case when we want 34 so 2 is not the position it will do hight = mid -1 =1 arr[1]=34 wich is true and so on until low>higt.
### algorithm :
1. read the sorted array and give the insial values to the variables low=0 high=size-1
2. while calculate the mid by mid=higt + low /2
3. check if arr[mid]=value if yes then return mid 
4. if no if arr[mid] < value then high = mid-1 check mid again 
5. if arr[mid] > value the low = mid +1 check mid again 
# function : bubbleSort
## problem analysis and example :
- input : i,j,flag,temp,size,art[]
- output : sorted array
- example :let us say we have array [4,1,2,5,3] we use this funtion to sort it it will copare each element with its niegber so it will copare 4 and 1 and 1 is less then 4 so they will change position now it will compare 4 with 2 same thing change position 4 and 5 dont change 5 and 3 change now it will do the same process until we get a sorted arry like this [1,2,3,4,5] if it did swap it any element it will return the flag 1 else it will return 0 wich going to tell the function to break and not excute the rest of the code
### algorithm :
1. stat with first elements 
2. then flag is set to 0  
3. then checking the adjecent element and while the fisrt is less then the second swap it 
4. if it swaped even one time the flag then sets to 1 
5. if the element is sorted the element is out of the array 
# function : selectionSort
## problem analysis and example :
- input : i,j,min,minindex,temp
- output : a sorted array .
- example : let us say we have an unsorted array [3,1,9,4,0] we will start a loop that take the first element from our array so the index start from 0 minindex the value in this case is 3 and then start another loop start from i+1 to size ifthe element of the index j is less that the one it will do the same process until the array is sorted
### algorithm :
1. stat a loop from 0 
2. give minindex the values of the index of the loop 
3. start another loop start from j = i+1 such as i is the index of the first loop
4. check if the array element in j is less then minindex if yes min index 
5. and then swap the elements 
# function : mergeSort
## problem analysis and example :
- input : left,right,mid,temp
- output : a sorted array .
- example : let us say we have an unsorted array [8,3,1,6,2] the function will divide the array into smaller parts recursively until each part contains only one element . then the merge function will combine the small sorted arrays together in the correct order until the whole array becomes sorted .
### algorithm :
1. check if left is less then right
2. calculate the middle index mid = (left + right) / 2
3. call mergeSort for the left half from left to mid
4. call mergeSort for the right half from mid+1 to right
5. call the merge function to combine the two sorted halves
6. use a temporary array to store the merged elements
7. copy the sorted elements back into the original array
# function : quickSort
## problem analysis and example :
- input : low,high,pivot,i,j,temp
- output : a sorted array .
- example : let us say we have an unsorted array [7,2,9,1,5] we choose the last element as pivot in this case 5 . we compare the elements with the pivot and place the smaller elements before it and bigger elements after it . then we recursively apply the same process on the left and right parts until the array becomes sorted .
### algorithm :
1. check if low is less then high
2. choose the last element as pivot
3. start a loop from low to high-1
4. compare each element with the pivot
5. if the element is smaller then pivot swap it with the correct position
6. after the loop place the pivot in its correct position
7. recursively call quickSort on the left side
8. recursively call quickSort on the right side
# function : findMax
## problem analysis and example :
- input : i, max
- output : max
- example : let us say we have this array [12,5,-4,6,37] this function will take the first element as the max in this case will be 12 and it will compare it with all the other elements if it finds an element more then 12 it will take it as the new max 37
### algorithm :
1. give max the value of the first element of the array 
2. checking in the rest of array if there is any value that is more then the value of max
3. if it finds it it will change it
# function : findMin
## problem analysis and example :
- input : i, min
- output : min
- example : let us say we have this array [12,5,-4,6,37] this function will take the first element as the max in this case will be 12 and it will compare it with all the other elements if it finds an element less then 12 it will take it as the new 5 and continue searching until it finds the smallest element 
### algorithm :
1. give max the value of the first element of the array 
2. checking in the rest of array if there is any value that is more then the value of max
3. if it finds it it will change it
# function : sumArray
## problem analysis and example :
- input:  i,total
- output : the sum of an array
- example : let us say that [12,5,-4,6] is the input array the function will calculat and return the sum like in this example it will return 19.
### algorithm :
1. check if the array is empty if yes return 0
2. else start the loop from 0 and the total value to 0
3. each time the total value will increase by the element on the array
4. lastly return the sum
# function : averageArray
## problem analysis and example :
- input : 
- output : the avrage of the array 
- example : let us say we have this array [12,5,-4,6] this function will calculate the sum which is 19 then devide it by the number of elenmt this is the average that this function will return in this case is 3(because it returns integer) 
### algorithm :
1. check if the array is empty if yes it will return 0.0
2. else it will calclater the sum of all element like the privious function(sumArray)
3. an it will return that sum devided by the number of elenmt 
# function : reverseArray
## problem analysis and example :
- input : i, temp
- output : the reversed array 
- example : let us say we have this array [12,5,-4,6] this function will revers the array by swaping the symitrical element until it reach the middel and the output will be[6,-4,5,12]
### algorithm :
1. take each symitrical element in the array
2. swap them 
3. do the same thing until it reach the middle
# function : rotateLeft
## problem analysis and example :
- input : size,k,temp,i
- output : a rotated array .
- example : let us say we have an array [1,2,3,4,5] and k = 2 . after rotating to the left the first two elements move to the end of the array and the result becomes [3,4,5,1,2] .
### algorithm :
1. calculate k % size to avoid unnecessary rotations
2. repeat the rotation k times
3. save the first element in a temporary variable
4. shift all elements one position to the left
4. place the saved element at the end of the array
5. repeat until all rotations are completed
# function : mergeSortedArrays
## problem analysis and example :
- input : i,j,k,na,nb
- output : a merged sorted array .
- example : let us say we have two sorted arrays a = [1,3,5] and b = [2,4,6] . we compare the elements of both arrays and place the smaller one into the output array . the final result becomes [1,2,3,4,5,6] .
### algorithm :
1. initialize three indexes i,j,k with 0
2. compare elements of arrays a and b
3. copy the smaller element into the output array
4. increment the corresponding index
5. repeat until one array becomes empty
6. copy the remaining elements from the other array
7.the output array will contain all elements in sorted order
=================Part B — 2D Static Matrices=================
# function : initMatrix
## problem analysis and example :
- input : i,j
- output : the input array 
- example : the user enters elemets this function will put them in a matrix ex: m[2][2]|2 6  |
                                                                                       |-1 3 |
### algorithm :
1. check if the size of the matrix is valid if no print invalid matrix
2. if yes start reading the element of the matrix from the user
# function : printMatrix
## problem analysis and example :
- input : i,j
- output : the element of the matrix 
- example : this funtion will display all the element of a matrix and leave an empty line between each row like this 
12 34 56 

85  0 16

19 -3  1
### algorithm :
1. print all of the element of an array 
2. leave an empty line between each row
# function : transposeMatrix
## problem analysis and example :
- input : 
- output : the transpose of the matrix 
- example : let us say that this is our matrix 5  2  9 it will give us 5  6  1
                                               6 -1  4                 2 -1  1
                                               1  1  0                 9  4  0 
### algorithm :
1. it will take the matrix 
2. then it will swap the index of the rows with the one of the colomns
# function : addMatrices
## problem analysis and example :
- input : 
- output : the matrix that is the result of the addition of two matrixes
- example :let us say that this is our matrixes 5  2  9 and  5  6  1 the result will be 10 8 10 
                                               6 -1  4      2 -1  1                     8 -2 5
                                               1  1  0      9  4  0                     10 5 0
### algorithm :
1. it will take two matrix need to be from the same nature 
2. it will do the addition between each two elements from the two arrays in same postion 
3. it will give us an array from the same nature and it is the resut of the addition
# function : multiplyMatrices
## problem analysis and example :
- input : 
- output : the matrix of the result of multiplying two matrixes
- example :let us say that this is our matrixes 5  2  9 and  5  6  1 the result will be 110   64   7
                                                6 -1  4      2 -1  1                     64   53   5
                                                1  1  0      9  4  0                      7    5   2                   
### algorithm :
1. it will take two matrix need to be square
2. do the multplication between them
3. give us the result matrix
# function : sumDiagonal
## problem analysis and example :
- input :
- output : the sum of the diagonal of the matrix 
- example : let us say that this is our matrix 5  2  9 it will give us 4 =5+(-1)+0
                                               6 -1  4              
                                               1  1  0 
### algorithm :        
1. it will calculate the sume of the elements of the matrix thAT THE row = the coulmn 
2. the diagonal and calculate the sum of these element and give it 
# function : sumAntiDiagonal        
## problem analysis and example :
- input : 
- output : gve the sum of all element of the upper tringle
- example : let us say that this is our matrix 5  2  9 it will give us 15 =9+2+4
                                               6 -1  4              
                                               1  1  0 
### algorithm :
1. it will take the matrix 
2. then it will do the addision between all elements of m[i][i+1]
3. that will be the sum of all element of the upper tringel
# function : isSymmetric
## problem analysis and example :
- input : 
- output : 1 for symitric 0 for not symitric
- example : let us say that this is our matrix 5  2  9 it will copare all elements like m[i][j]and m[j][i]
                                               6 -1  4   if all the same it will return one but in our case            
                                               1  1  0   it will return 0.(not symitric)
# function : sortRows
## problem analysis and example :
- input : rows,cols,i,j,k,temp
- output : a matrix with sorted rows .
- example : let us say we have a matrix
[3,1,2]
[9,4,7]

the function will sort each row independently . the first row becomes [1,2,3] and the second row becomes [4,7,9] .
### algorithm :
1. start a loop through all rows
2. for each row apply a sorting algorithm
3. compare adjacent elements in the same row
4. if the first element is greater then the second swap them
5. repeat until the row becomes sorted
6. continue the same process for all rows
=================Part C — Dynamic Arrays=================
# function : createDynamicArray
## problem analysis and example :
- input : 
- output : the adress of the allocated array 
- example : we want to allocate a memory slot for our array which contains 5 element this function will allocate the memory slot .
### algorithm :
1. call malloc to allocate the space that we need 
2. then check if it is allocated or not 
3. if not return NULL
4. else return the adress of the first element 
# function : fillArray
## problem analysis and example :
- input : 
- output : fill the array
- example : we want to fill an array of five element we call our function and enter the element we want to put on the array ex: 1 , 4, 89, -10 ,0 it will be stored on the array [1,4,89,-10,0]
### algorithm :
1. fill the element of the array by the user input 
2. one by one until the lenght of our array
# function : resizeArray
## problem analysis and example :
- input : 
- output : adress of the expanded array or error
- example : we have an array and we want to expand it we call this function to add space for the array to add new element like the previous array we wanrt to add 18, 30 to it we epand it and we add the elements
### algorithm :
1. call the functin realloc to add or erace ellements
2. if the process is not secussful it return null and print error 
3. else if secssful it will return the new adress
# function : freeArray
## problem analysis and example :
- input : 
- output : free memory space 
- example : it just free a memmory space ex: the array [1,4,89,-10,0] will be freed frm the memory address so the arr =null
### algorithm :
1. we call the function free
2. it will go to the adress and free it and the value of the aRRAY WILL be null.
========================================================================================================================
                    ***** Module 2 _ LINKED LISTS , STACKS & QUEUES ***** 
=================Part A — Singly Linked List=================
# function : initList
## problem analysis and example :
- input : 
- output : insilase the linked list before using it 
- example : let us say we worked before with a linked list and it still have the old values 12,34,67 and it have the size of 3 elemts like this [12|.][34|.][67|NULL] after we use this function it will make the size of it 0 and list empty
### algorithm :
1. sets head to NULL (empty)
2. sets the size to 0 so we left with an empty list 
# function : insertBeginning
## problem analysis and example :
- input : 
- output : a linked list that has a new head
- example :lets say that we have a linked list like this [12|.][34|.][67|NULL] we want to add 33 at the begining so 33 will be our new head first the function will create a new node [33|NULL] we will make this new node pointes to the privous head and the size of our linked list will increase by 1 and the new linked list will be like this [33|.] [12|.][34|.][67|NULL]
### algorithm :
1. first creat a new node 
2. checks if it is created 
3. the new node data will hold the value and it will point to the head 
4. and the new node will be the new node
5. increse the size by 1
# function : insertEnd
## problem analysis and example :
- input : 
- output : a linked list that has a new tail
- example : let us say that we have a linked list like this [12|.][34|.][67|NULL] we want to add 33 at the end so 33 will be our new tail first the function will create a new node [33|NULL] we will make this new node the tail of the liked list so we we will go the privious node and make it points to our new node and the linked list will be like that [12|.][34|.][67|.][33|NULL]
### algorithm :
1. first creat a new node 
2. checks if it is created 
3. the new node data will hold the value and it will point to NULL
4. the privious tail will be pointing to the new node instead of NULL
5. and the new node will be the new tail
6. increse the size by 1
# function : deleteBeginning
## problem analysis and example :
- input : 
- output : a linked list that its head has been deleted and replaced by the next element
- example : let us say that we have a linked list like this [12|.][34|.][67|NULL] we use this function to delet the head and make the second element the head and return us the value of the first head so in this case it will return 12 and delete the node [12|.] 
### algorithm :
1. checks if the list is empty if yes returns -1 (error)
2. if no creats a node temp that holds the head 
3. save the value of the head on a variable value 
4. make the second element the new head 
5. free the privoious head 
6. return the value and decrease the size of our list by 1
# function : deleteEnd
## problem analysis and example :
- input : current,previous
- output : the deleted value or -1 if the list is empty .
- example : let us say we have a linked list 10 → 20 → 30 → NULL . the function will traverse until the last node then remove the node containing 30 and update the previous node to point to NULL . the new list becomes 10 → 20 → NULL .
### algorithm :
1. check if the list is empty
2. if the list is empty return -1
3. check if the list contains only one node
4. if yes save the value free the node and set head to NULL
5. otherwise traverse the list until the last node
6. keep track of the previous node
7. unlink the last node by setting previous->next to NULL
8. free the last node
9. return the deleted value
# function : deleteByValue
## problem analysis and example :
- input : current,previous,value
- output : the deleted value or -1 if the value is not found .
- example : let us say we have a linked list 10 → 20 → 30 → NULL and we want to delete 20 . the function will search for the node containing 20 then unlink it by making the previous node point to the next node . the new list becomes 10 → 30 → NULL .
### algorithm :
1. check if the list is empty
2. if the list is empty return -1
3. check if the head contains the value
4. if yes move the head to the next node and free the old head
5. otherwise traverse the list until the value is found
6. keep track of the previous node
7. redirect previous->next to current->next
8. free the current node
9. return the deleted value
10. if the value is not found return -1
# function : searchValue
## problem analysis and example :
- input : current,value
- output : pointer to the node if the value is found or NULL if not found .
- example : let us say we have a linked list 10 → 20 → 30 → NULL and we search for the value 20 . the function will traverse the list from the head until it finds the node containing 20 then return a pointer to that node . if the value does not exist it returns NULL .
### algorithm :
1. start from the head node
2. traverse the linked list node by node
3. compare each node data with the given value
4. if the value is found return the pointer to that node
5. continue until the end of the list
6. if the value is not found return NULL
# function : displayList
## problem analysis and example :
- input : current
- output : display the linked list elements .
- example : let us say we have a linked list 10 → 20 → 30 → NULL . the function will start from the head and print each node value until it reaches NULL .
### algorithm :
1. start from the head node
2. traverse the linked list node by node
3. print the value of each node
4. move to the next node
5. repeat until current becomes NULL
6. print NULL at the end of the list
# function : reverseList
## problem analysis and example :
- input : previous,current,next
- output : a reversed linked list .
- example : let us say we have a linked list 10 → 20 → 30 → NULL . the function will reverse the direction of the links between the nodes so the new list becomes 30 → 20 → 10 → NULL .
### algorithm :
1. initialize previous with NULL
2. initialize current with the head of the list
3. traverse the linked list until current becomes NULL
4. save the next node in a temporary pointer
5. reverse the link of the current node
6. move previous to current
7. move current to next
8. after the loop update head to previous
# function : sortListBubble
## problem analysis and example :
- input : current,next,temp
- output : a sorted linked list .
- example : let us say we have a linked list 30 → 10 → 20 → NULL . the function will compare adjacent node values and swap them if they are not in order . after repeating the process the list becomes 10 → 20 → 30 → NULL .
### algorithm :
1. check if the list is empty
2. start a loop through the linked list
3. compare adjacent node values
4. if the first value is greater then the second swap their data
4. continue until the end of the list
5. repeat the process until the list becomes sorted
# function : mergeSortedLists
## problem analysis and example :
- input : currentA,currentB
- output : a merged sorted linked list .
- example : let us say we have two sorted linked lists
A : 1 → 3 → 5 → NULL
B : 2 → 4 → 6 → NULL

the function will compare the nodes of both lists and insert the smaller value into the result list until all nodes are merged . the final result becomes
1 → 2 → 3 → 4 → 5 → 6 → NULL .

### algorithm :
1. initialize the result list
2. create two pointers for lists A and B
3. compare the values of both nodes
4. insert the smaller value into the result list
5. move the pointer of the inserted value
6. repeat until one list becomes empty
7. copy the remaining elements from the other list
8. the result list will contain all elements in sorted order
=================Part B — Doubly Linked List=================
# function : initListDLL
## problem analysis and example :
- input : head,tail,size
- output : an initialized doubly linked list .
- example : when we create a new doubly linked list it does not contain any nodes . the function initializes the list by setting head and tail to NULL and size to 0 .
### algorithm :
1. set head to NULL
2. set tail to NULL
3. set size to 0
4. the doubly linked list is now empty and ready to use
# function : insertBeginningDLL
## problem analysis and example :
- input : newNode,value
- output : a doubly linked list with a new node - - inserted at the beginning .
- example : let us say we have a doubly linked list 20 ⇄ 30 ⇄ NULL and we want to insert 10 at the beginning . the function will create a new node and make it the new head . the new list becomes 10 ⇄ 20 ⇄ 30 ⇄ NULL .
### algorithm :
1. allocate memory for a new node
2. check if memory allocation failed
3. store the value in the new node
4. set newNode->prev to NULL
5. set newNode->next to the current head
6. if the list is not empty set head->prev to newNode
7. update head to newNode
8. if the list was empty update tail to newNode
9. increment the size of the list
10. return 0 on success or -1 on failure
# function : insertEndDLL
## problem analysis and example :
- input : newNode,value
- output : a doubly linked list with a new node inserted at the end .
- example : let us say we have a doubly linked list 10 ⇄ 20 ⇄ NULL and we want to insert 30 at the end . the function will create a new node and link it after the tail . the new list becomes 10 ⇄ 20 ⇄ 30 ⇄ NULL .
### algorithm :
1. allocate memory for a new node
2. check if memory allocation failed
3. store the value in the new node
4. set newNode->next to NULL
5. set newNode->prev to the current tail
6. if the list is not empty set tail->next to newNode
7. update tail to newNode
8. if the list was empty update head to newNode
9. increment the size of the list
10. return 0 on success or -1 on failure
# function : deleteByValueDLL
## problem analysis and example :
- input : current,value
- output : the deleted value or -1 if the value is not found .
- example : let us say we have a doubly linked list 10 ⇄ 20 ⇄ 30 ⇄ NULL and we want to delete 20 . the function will find the node containing 20 then update the previous and next pointers to bypass it . the new list becomes 10 ⇄ 30 ⇄ NULL .
### algorithm :
1. check if the list is empty
2. if the list is empty return -1
3. traverse the doubly linked list until the value is found
4. if the value is not found return -1
5. if the node is the head update head
6. if the node is the tail update tail
7. update previous and next pointers
8. free the node
9. decrement the size of the list
10. return the deleted value
# function : displayForward
## problem analysis and example :
- input : current
- output : display the doubly linked list from head to tail .
- example : let us say we have a doubly linked list 10 ⇄ 20 ⇄ 30 ⇄ NULL . the function will start from the head and print each node value in order until it reaches NULL .
### algorithm :
1. start from the head node
2. traverse the doubly linked list using next pointers
3. print the value of each node
4. move to the next node
5. repeat until current becomes NULL
6. print NULL at the end of the list
# function : displayBackward
## problem analysis and example :
- input : current
- output : display the doubly linked list from tail to head .
- example : let us say we have a doubly linked list 10 ⇄ 20 ⇄ 30 ⇄ NULL . the function will start from the tail and print each node value in reverse order until it reaches NULL . the output becomes 30 ⇄ 20 ⇄ 10 ⇄ NULL .
### algorithm :
1. start from the tail node
2. traverse the doubly linked list using prev pointers
3. print the value of each node
4. move to the previous node
5. repeat until current becomes NULL
6. print NULL at the end of the list
=================Part C — Stack =================
# function : initStack
## problem analysis and example :
- input : top
- output : an initialized stack .
- example : when we create a new stack it does not contain any nodes . the function initializes the stack by setting top to NULL which means the stack is empty and ready to use .
### valgorithm :
1. set top to NULL
2. the stack is now empty
3. the stack is ready for push and pop operations
=================Part D — Queue =================
# function : initStack
## problem analysis and example :
- input : top
- output : an initialized stack .
- example : when we create a stack it does not contain any elements . the function initializes the stack by setting top to NULL which means the stack is empty and ready to use .
### algorithm :
1. set the top pointer to NULL
2. the stack becomes empty
3. the stack is now ready for push and pop operations
========================================================================================================================
                    ***** Module 3 _ File Handling ***** 
# function : createBinaryFile
## problem analysis and example :
- input : filename,fp
- output : return 0 on success or -1 on failure .
- example : let us say we want to create a binary file called "students.dat" . the function will open the file in write binary mode which creates an empty binary file . if the file is created successfully the function returns 0 otherwise it returns -1 .
### algorithm :
1. open the file using fopen with "wb" mode
2. check if the file pointer is NULL
3. if the file cannot be opened return -1
4. close the file
5. return 0
# function : writeRecord
## problem analysis and example :
- input : filename,r,fp
- output : return 0 on success or -1 on failure .
- example : let us say we have a record with
id = 1
name = "Abderrahmane"
score = 15.05
category = "CS"

the function will open the binary file in append mode and write the record at the end of the file . if the operation succeeds the function returns 0 otherwise it returns -1 .

### algorithm :
1. open the file using fopen with "ab" mode
2. check if the file pointer is NULL
3. if the file cannot be opened return -1
4. write the record into the file using fwrite
5. check if fwrite failed
6. close the file
7. return 0 on success or -1 on failure
========================================================================================================================
                    ***** Module 4 _ String Utils ***** 
# function : my_strlen
## problem analysis and example :
- input : s,i
- output : the length of the string .
- example : let us say we have a string "hello" . the function will count the characters one by one until it reaches the null character '\0' . the result will be 5 .
###algorithm :
1. initialize a counter variable i with 0
2. traverse the string character by character
3. check if the current character is not '\0'
4. increment the counter
5. repeat until the null terminator is reached
6. return the counter value   
# function : my_strcpy
## problem analysis and example :
- input : dest,src,i
- output : a copied string in dest .
- example : let us say we have a source string "hello" . the function will copy each character from src into dest until it reaches the null terminator '\0' . after the copy dest becomes "hello" .
### algorithm :
1. initialize an index variable i with 0
2. traverse the source string character by character
3. copy each character from src to dest
4. continue until the null terminator is copied
5. return dest    
========================================================================================================================
                    ***** Module Bonus*****   
# function : loadDataset
## problem analysis and example :
- input : filename,arr,count,fp
- output : records loaded from a binary file into an array .
- example : let us say we have a binary file containing student records . the function reads all records from the file and stores them into the array then updates count with the number of loaded records .
### algorithm :
1. open the binary file in read mode
2. check if the file pointer is NULL
3. initialize count with 0
4. read records using fread
5. store each record into the array
6. increment count after each successful read
7. close the file
8. return 0 on success or -1 on failure
# function : displayDataset
## problem analysis and example :
- input : arr,count,i
- output : display all dataset records .
- example : the function prints all records in a formatted table showing id , name , score and category .
### algorithm :
1. print the table headers
2. start a loop through all records
3. print each record using formatted output
4. continue until all records are displayed
# function : sortDatasetByField
## problem analysis and example :
- input : arr,count,field,temp,i,j
- output : a sorted dataset .
- example : if field = "score" the function sorts the records according to their score values from smallest to largest . if field = "name" it sorts alphabetically .
### algorithm :
1. start nested loops for sorting
2. compare records depending on the selected field
3. if the records are not in order swap them
4. continue until all records are sorted
# function : findMaxByField
## problem analysis and example :
- input : arr,count,i,max
- output : the record with the maximum score .
- example : if we have multiple student records the function searches for the student with the highest score and returns the full record .
### algorithm :
1. initialize max with the first record
2. traverse all records
3. compare the score values
4. update max if a higher score is found
5. return the max record
# function : findMinByField
## problem analysis and example :
- input : arr,count,i,min
- output : the record with the minimum score .
- example : if we have multiple student records the function searches for the student with the lowest score and returns the full record .
### algorithm :
1. initialize min with the first record
2. traverse all records
3. compare the score values
3. update min if a lower score is found
4. return the min record
# function : averageByField
## problem analysis and example :
- input : arr,count,i,sum
- output : the average score .
- example : if the scores are 10 , 15 and 20 the function calculates their average and returns 15 .
### algorithm :
1. check if count is equal to 0
2. initialize sum with 0
3. traverse all records
4. add all scores to sum
5. divide sum by count
6. return the average value
# function : filterByCondition
## problem analysis and example :
- input : arr,count,threshold,out,i,j
- output : filtered records .
- example : if threshold = 10 the function copies all records with score greater than 10 into the output array .
### algorithm :
initialize j with 0
traverse all records
compare each score with the threshold
if the score is greater copy the record into out
increment j
return the number of filtered records
# function : saveBinaryReport
## problem analysis and example :
input : filename,arr,count,fp,i
output : save records into a binary report file .
example : after sorting or filtering the dataset the function writes all records into a new binary file .
### algorithm :
open the file in write binary mode
check if the file pointer is NULL
traverse all records
write each record into the file using fwrite
close the file
return 0 on success or -1 on failure