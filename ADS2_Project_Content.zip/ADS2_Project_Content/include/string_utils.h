#ifndef STRINIG_UTILS_H
#define STRING_UTILS_H
#include "common.h"
int my_strlen(const char* s);
char* my_strcpy(char* dest, const char* src);
#endif