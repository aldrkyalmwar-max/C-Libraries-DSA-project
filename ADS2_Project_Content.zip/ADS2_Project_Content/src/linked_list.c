#include "../include/linked_list.h"
#include <stdio.h>
#include <stdlib.h>
void initList(List* L){
    L -> head = NULL;
    L -> size =0;
}
int insertBeginning(List* L, int value){
    Node* new = (Node*) malloc(sizeof(Node));
    if(new == NULL){
        return -1;
    }
    new -> data = value;
    new -> next = L -> head ;
    L -> head = new;
    L -> size ++;
    return 0;
}
int insertEnd(List* L, int value){
    Node* newNode = (Node*) malloc(sizeof(Node));
    if(newNode == NULL) return -1;
    newNode->data = value;
    newNode->next = NULL;
    if(L->head == NULL){
        L->head = newNode;
    } else {
        Node* p = L->head;
        while(p->next != NULL){
            p = p->next;
        }
        p->next = newNode;
    }
    L->size++;
    return 1;
}
int deleteBeginning(List* L){
    if (L->head==NULL){
        return -1;
    }
    Node* temp =L->head;
    int value=L->head->data; 
    L->head=L->head->next;
    free(temp);
    return value;
    L->size --;
}
int deleteEnd(List* L){
    if (L->head == NULL){
        return -1;   
    }
    Node* p = L->head;
    if (p->next == NULL){
        int value = p->data;
        free(p);
        L->head = NULL;
        L->size--;
        return value;
    }
    while (p->next->next != NULL){
        p = p->next;
    }
    Node* temp = p->next;   
    int value = temp->data;
    p->next = NULL;   
    free(temp);
    L->size--;
    return value;
}
int deleteByValue(List* L, int value) {
    if(L->head == NULL) {
        return -1;
    }
    if(L->head->data == value) {
        Node* temp = L->head;
        L->head = L->head->next;
        free(temp);
        return value;
    }
    Node* current = L->head;
    Node* previous = NULL;
    while(current != NULL && current->data != value) {
        previous = current;
        current = current->next;
    }
    if(current == NULL) {
        return -1;
    }
    previous->next = current->next;
    free(current);
    return value;
}
Node* searchValue(List* L, int value) {
    Node* current = L->head;
    while(current != NULL) {
        if(current->data == value) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}
void displayList(List* L) {
    Node* current = L->head;
    while(current != NULL) {
        printf("%d -> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}
void reverseList(List* L) {
    Node* previous = NULL;
    Node* current = L->head;
    Node* next = NULL;
    while(current != NULL) {
        next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }
    L->head = previous;
}
void sortListBubble(List* L) {
    if(L->head == NULL) {
        return;
    }
    Node* current;
    Node* next;
    int temp;
    int swapped;
    do {
        swapped = 0;
        current = L->head;
        while(current->next != NULL) {
            next = current->next;
            if(current->data > next->data) {
                temp = current->data;
                current->data = next->data;
                next->data = temp;
                swapped = 1;
            }
            current = current->next;
        }
    } while(swapped);
}
void mergeSortedLists(List* A, List* B, List* result) {
    initList(result);
    Node* currentA = A->head;
    Node* currentB = B->head;
    while(currentA != NULL && currentB != NULL) {
        if(currentA->data < currentB->data) {
            insertEnd(result, currentA->data);
            currentA = currentA->next;
        } else {
            insertEnd(result, currentB->data);
            currentB = currentB->next;
        }
    }
    while(currentA != NULL) {
        insertEnd(result, currentA->data);
        currentA = currentA->next;
    }
    while(currentB != NULL) {
        insertEnd(result, currentB->data);
        currentB = currentB->next;
    }
}
                    /*Part B — Doubly Linked List*/
void initListDLL(DLL* L) {
    L->head = NULL;
    L->tail = NULL;
    L->size = 0;
}
int insertBeginningDLL(DLL* L, int value) {
    DNode* newNode = (DNode*)malloc(sizeof(DNode));
    if(newNode == NULL) {
        return -1;
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = L->head;
    if(L->head != NULL) {
        L->head->prev = newNode;
    }
    L->head = newNode;
    if(L->tail == NULL) {
        L->tail = newNode;
    }
    L->size++;
    return 0;
}
}
int insertEndDLL(DLL* L, int value) {
    DNode* newNode = (DNode*)malloc(sizeof(DNode));
    if(newNode == NULL) {
        return -1;
    }
    newNode->data = value;
    newNode->next = NULL;
    newNode->prev = L->tail;
    if(L->tail != NULL) {
        L->tail->next = newNode;
    }
    L->tail = newNode;
    if(L->head == NULL) {
        L->head = newNode;
    }
    L->size++;
    return 0;
}
int deleteByValueDLL(DLL* L, int value) {
    if(L->head == NULL) {
        return -1;
    }
    DNode* current = L->head;
    while(current != NULL && current->data != value) {
        current = current->next;
    }
    if(current == NULL) {
        return -1;
    }
    if(current == L->head) {
        L->head = current->next;
    }
    if(current == L->tail) {
        L->tail = current->prev;
    }
    if(current->prev != NULL) {
        current->prev->next = current->next;
    }
    if(current->next != NULL) {
        current->next->prev = current->prev;
    }
    free(current);
    L->size--;
    return value;
}
void displayForward(DLL* L) {
    DNode* current = L->head;
    while(current != NULL) {
        printf("%d <-> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}
void displayBackward(DLL* L) {
    DNode* current = L->tail;
    while(current != NULL) {
        printf("%d <-> ", current->data);
        current = current->prev;
    }
    printf("NULL\n");
}
                    /*Part C — Stack*/
void initStack(Stack* S) {
    S->top = NULL;
}
                    /*Part D — Queue*/