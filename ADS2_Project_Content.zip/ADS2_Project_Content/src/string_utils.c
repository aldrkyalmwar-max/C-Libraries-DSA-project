#include "../include/string_utils.h"
#include <stdio.h>
#include <stdlib.h>
int my_strlen(const char* s) {
    int i = 0;
    while(s[i] != '\0') {
        i++;
    }
    return i;
}
char* my_strcpy(char* dest, const char* src) {
    int i = 0;
    while(src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    return dest;
}