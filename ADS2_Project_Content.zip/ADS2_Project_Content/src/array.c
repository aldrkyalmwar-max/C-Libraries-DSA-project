#include "../include/array.h" 
#include <stdio.h>
#include <stdlib.h>
                    /*Part A — 1D Static Arrays*/
void initArray(int arr[], int* size) {     //we use this procedure before any other array function just to rest the size
    *size = 0;
}

void printArray(int arr[], int size) {    //we use this function just to write the element of an array like this [a,b,c,....]
    printf("[");
    for (int i = 0; i < size; i++) {
        printf("%d", arr[i]);
        if (i < size - 1) printf(", ");
    }
    printf("]\n");
}

int insertAt(int arr[], int* size, int index, int value) {  //this function add an element on the array cetain place 
    if (index < 0 || index > *size) return -1;  
    if (*size >= MAX_1D) return -1;             

    for (int i = *size; i > index; i--)
        arr[i] = arr[i - 1];

    arr[index] = value;
    (*size)++;
    return 0;
}
int deleteAt(int arr[], int* size, int index){   //this function delete a cetain element from an array  
    int i;
    if (index<0||index>=*size){  
    return -1;
    }
    for(i=index;i<*size-1;i++){
    arr[i]=arr[i+1];
    }
    (*size)--;
    return 0;
    }
int linearSearch(int arr[], int size, int value){  //this function will give us the position of our element on the array
    int i;
    for(i=0;i<=size-1;i++){
    if(arr[i]==value){
    return i;
    }
    }
    return -1;

}
int binarySearch(int arr[], int size, int value){ //this function search for the position of a certain value in a sorted array 
    int low=0,high=size-1,mid;
    while(low<=high){
        mid = (low+high)/2;
        if(arr[mid]==value){
            return mid;
        }
        else if(value<arr[mid]){
            high=mid-1;
        }
        else{
            low=mid+1;
        }
    }
    return -1;
}
void bubbleSort(int arr[], int size){ //this function sort a given array 
    int i,j,flag=0,temp;
    for(i=0;i<size-1;i++){
        flag=0;
        for(j=0;j<size-i-1;j++){
            if(arr[j]>arr[j+1]){
                temp=arr[j+1];
                arr[j+1]=arr[j];
                arr[j]=temp;
                flag=1;
            }
        }
        if(flag==0){
            break;
        }
    }
}
void selectionSort(int arr[], int size){
    int i,j,min,minindex,temp;

    for(i=0;i<=size-1;i++){
        minindex=i;
        for(j=i+1;j<size;j++){
            if (arr[j]<arr[minindex]){
                minindex=j;
            }
            }
        }
        temp=arr[i];
        arr[i]=arr[minindex];
        arr[minindex]=temp;
 }
void insertionSort(int arr[], int size){
    int i ,temp ,j ;
    for (i=1;i<=size-1;i++){
        temp=arr[i];
        j=i-1;
        while(j>=0 && arr[j]>temp ){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=temp;
    }
}
void mergeSort(int arr[], int left, int right){
    if(left < right) {
        int mid = (left + right) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        int i = left;
        int j = mid + 1;
        int k = 0;
        int temp[right - left + 1];
        while(i <= mid && j <= right) {
            if(arr[i] < arr[j]) {
                temp[k] = arr[i];
                i++;
            } else {
                temp[k] = arr[j];
                j++;
            }
            k++;
        }
        while(i <= mid) {
            temp[k] = arr[i];
            i++;
            k++;
        }
        while(j <= right) {
            temp[k] = arr[j];
            j++;
            k++;
        }
        for(i = left, k = 0; i <= right; i++, k++) {
            arr[i] = temp[k];
        }
    }
}
void quickSort(int arr[], int low, int high){
    if(low < high) {
        int pivot = arr[high];
        int i = low - 1;
        int j, temp;
        for(j = low; j < high; j++) {
            if(arr[j] < pivot) {
                i++;

                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        int pi = i + 1;
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
int findMax(int arr[], int size){
    int i,max; 
    max=arr[0];
    for(i=1;i<=size-1;i++){
        if (arr[i]>max){
            max= arr[i];
        }
    }
    return max;
}
int findMin(int arr[], int size){
    int i,min; 
    min=arr[0];
    for(i=1;i<=size-1;i++){
        if (arr[i]<min){
            min= arr[i];
        }
    }
    return min;
}
int sumArray(int arr[], int size){
    int i,total=0;
    if(size == 0){
        return 0; 
    }
    for(i=0;i<=size-1;i++){
        total=total+arr[i];
    }
    return total;

}
double averageArray(int arr[], int size){
    if (size==0){
    return 0.0;}
    double sum=0;
    int i;
    for(i=0;i<=size-1;i++){
        sum = sum+arr[i];
    }
    return sum/size;
}
void reverseArray(int arr[], int size){
    int i, temp;
    for(i=0;i<(size/2);i++){
        temp=arr[i];
        arr[i]=arr[size-i-1];
        arr[size-i-1]=temp;
    }
}
void rotateLeft(int arr[], int size, int k){
       int i, j, temp;
    k = k % size;
    for(i = 0; i < k; i++) {
        temp = arr[0];
        for(j = 0; j < size - 1; j++) {
            arr[j] = arr[j + 1];
        }
        arr[size - 1] = temp;
    }
}
void mergeSortedArrays(int a[], int na, int b[], int nb, int out[]){
    int i = 0,k = 0,j = 0;
    while(i < na && j < nb) {
        if(a[i] < b[j]) {
            out[k] = a[i];
            i++;
        } else {
            out[k] = b[j];
            j++;
        }
        k++;
    }
    while(i < na) {
        out[k] = a[i];
        i++;
        k++;
    }
    while(j < nb) {
        out[k] = b[j];
        j++;
        k++;
    }
}
                    /*Part B — 2D Static Matrices*/
void initMatrix(int m[][MAX_COLS], int* rows, int* cols){
    int i , j;
    if (*rows > MAX_ROWS  || *cols > MAX_COLS){
        printf("invalid matrix");
    }
    for (i=0;i<=*(rows-1);i++){
        for (j=0;j<=*(cols-1);i++){
            scanf("%d",&m[i][j]);
        }
    }
}
void printMatrix(int m[][MAX_COLS], int rows, int cols){
    int i,j;
    for(i=0;i<=rows-1;i++){
        for(j=0;j<=cols-1;j++){
            printf("%4d\n",m[i][j]);
        }
        printf("\n");
    }
}
void transposeMatrix(int m[][MAX_COLS], int rows, int cols, int out[][MAX_COLS]){
    int i,j;
    for(i=0;i<=rows-1;i++){
        for(j=0;j<=cols-1;j++){
            out[j][i]=m[i][j];
        }
}
}
void addMatrices(int a[][MAX_COLS], int b[][MAX_COLS], int r[][MAX_COLS], int rows, int cols){
    int i,j;
    for(i=0;i<=rows-1;i++){
        for(j=0;j<=cols-1;j++){
            r[i][j]=a[i][j]+b[i][j];
        }
    }
}
void multiplyMatrices(int a[][MAX_COLS], int b[][MAX_COLS], int r[][MAX_COLS], int n){
    int i,j,k;
    for (i=0;i<=n-1;i++){
        for(j=0;j<=n-1;j++){
            r[i][j]=0;
            for(k=0;k<=n-1;k++){
                r[i][j]=r[i][j]+(a[i][k]*b[k][j]);
            }
        }
    }
}
int sumDiagonal(int m[][MAX_COLS], int n){
    int i,sum=0;
    for (i=0;i<=n-1;i++){
        sum=sum+m[i][i];
    }
    return sum;
}
int sumAntiDiagonal(int m[][MAX_COLS], int n){
    int i,j,sum=0;
    for(i=0;i<=n-1;i++){
          sum =sum + m[i][n-1-i];
      }
      return sum;
}
int isSymmetric(int m[][MAX_COLS], int n){
    int i, j;
    for(i=0;i<=n-1;i++){
        for(j=i+1;j<=n-1;j++){
            if (m[i][j]!=m[j][i]){
                return 0;
            }
            
        }
    }
    return 1;
}
void sortRows(int m[][MAX_COLS], int rows, int cols){
    int i, j, k, temp;
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols - 1; j++) {

            for(k = 0; k < cols - j - 1; k++) {

                if(m[i][k] > m[i][k + 1]) {

                    temp = m[i][k];
                    m[i][k] = m[i][k + 1];
                    m[i][k + 1] = temp;
                }
            }
        }
    }
}
                    /*Part C — Dynamic Arrays*/
int* createDynamicArray(int capacity){
    int * arr= malloc(capacity*sizeof(int));
    if (*arr == NULL){
        printf("ERROR");
        return NULL;
    }
    return arr;
}
void fillArray(int* arr, int size){
    int i;
    for(i=0;i<=size-1;i++){
        scanf("%d",&arr[i]);
    }
}
int* resizeArray(int* arr, int newCapacity){
    int*temp =realloc(arr,newCapacity*sizeof(int));
    if (temp==NULL){
        printf("Error");
        return NULL;
    }
    return temp;
}
void freeArray(int* arr){
   free(*arr);
   *arr=NULL;
}