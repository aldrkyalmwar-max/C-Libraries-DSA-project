#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int id;
    char name[50];
    float score;
    char category[20];
} Record;

int loadDataset(const char* filename, Record arr[], int* count) {
    FILE* fp = fopen(filename, "rb");

    if(fp == NULL) {
        return -1;
    }

    *count = 0;

    while(fread(&arr[*count], sizeof(Record), 1, fp) == 1) {
        (*count)++;
    }

    fclose(fp);

    return 0;
}

void displayDataset(Record arr[], int count) {
    int i;

    printf("ID\tName\t\tScore\tCategory\n");

    for(i = 0; i < count; i++) {
        printf("%d\t%s\t\t%.2f\t%s\n",
               arr[i].id,
               arr[i].name,
               arr[i].score,
               arr[i].category);
    }
}

void sortDatasetByField(Record arr[], int count, char* field) {
    int i, j;
    Record temp;

    for(i = 0; i < count - 1; i++) {

        for(j = 0; j < count - i - 1; j++) {

            if(strcmp(field, "score") == 0) {

                if(arr[j].score > arr[j + 1].score) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }

            } else if(strcmp(field, "id") == 0) {

                if(arr[j].id > arr[j + 1].id) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }

            } else if(strcmp(field, "name") == 0) {

                if(strcmp(arr[j].name, arr[j + 1].name) > 0) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}

Record findMaxByField(Record arr[], int count) {
    int i;
    Record max = arr[0];

    for(i = 1; i < count; i++) {

        if(arr[i].score > max.score) {
            max = arr[i];
        }
    }

    return max;
}

Record findMinByField(Record arr[], int count) {
    int i;
    Record min = arr[0];

    for(i = 1; i < count; i++) {

        if(arr[i].score < min.score) {
            min = arr[i];
        }
    }

    return min;
}

float averageByField(Record arr[], int count) {
    int i;
    float sum = 0;

    if(count == 0) {
        return 0.0;
    }

    for(i = 0; i < count; i++) {
        sum += arr[i].score;
    }

    return sum / count;
}

int filterByCondition(Record arr[], int count, float threshold, Record out[]) {
    int i, j = 0;

    for(i = 0; i < count; i++) {

        if(arr[i].score > threshold) {
            out[j] = arr[i];
            j++;
        }
    }

    return j;
}

int saveBinaryReport(const char* filename, Record arr[], int count) {
    FILE* fp = fopen(filename, "wb");

    int i;

    if(fp == NULL) {
        return -1;
    }

    for(i = 0; i < count; i++) {

        fwrite(&arr[i], sizeof(Record), 1, fp);
    }

    fclose(fp);

    return 0;
}