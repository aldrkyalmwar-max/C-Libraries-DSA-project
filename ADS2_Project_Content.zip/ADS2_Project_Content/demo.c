#include <stdio.h>
#include <string.h>

#include "include/array.h"
#include "include/linked_list.h"
#include "include/stack.h"
#include "include/queue.h"
#include "include/file_utils.h"
#include "include/string_utils.h"

void arrayMenu() {

    int arr[MAX_1D];
    int size = 0;

    int choice;
    int index;
    int value;

    initArray(arr, &size);

    do {

        printf("\n=== ARRAY MENU ===\n");

        printf("1. Insert element\n");
        printf("2. Delete element\n");
        printf("3. Linear Search\n");
        printf("4. Bubble Sort\n");
        printf("5. Display Array\n");
        printf("6. Find Max\n");
        printf("7. Find Min\n");
        printf("8. Reverse Array\n");
        printf("0. Back\n");

        printf("Choice : ");
        scanf("%d", &choice);

        switch(choice) {

            case 1:

                printf("Enter index and value : ");
                scanf("%d %d", &index, &value);

                if(insertAt(arr, &size, index, value) == 0) {
                    printf("Element inserted successfully\n");
                } else {
                    printf("Insertion failed\n");
                }

                break;

            case 2:

                printf("Enter index : ");
                scanf("%d", &index);

                if(deleteAt(arr, &size, index) == 0) {
                    printf("Element deleted successfully\n");
                } else {
                    printf("Deletion failed\n");
                }

                break;

            case 3:

                printf("Enter value to search : ");
                scanf("%d", &value);

                index = linearSearch(arr, size, value);

                if(index != -1) {
                    printf("Value found at index %d\n", index);
                } else {
                    printf("Value not found\n");
                }

                break;

            case 4:

                bubbleSort(arr, size);

                printf("Array sorted successfully\n");

                break;

            case 5:

                printArray(arr, size);

                break;

            case 6:

                printf("Max value = %d\n", findMax(arr, size));

                break;

            case 7:

                printf("Min value = %d\n", findMin(arr, size));

                break;

            case 8:

                reverseArray(arr, size);

                printf("Array reversed successfully\n");

                break;

            case 0:

                printf("Returning...\n");

                break;

            default:

                printf("Invalid choice\n");
        }

    } while(choice != 0);
}

void linkedListMenu() {

    List L;

    initList(&L);

    int choice;
    int value;

    do {

        printf("\n=== LINKED LIST MENU ===\n");

        printf("1. Insert Beginning\n");
        printf("2. Insert End\n");
        printf("3. Delete Beginning\n");
        printf("4. Delete End\n");
        printf("5. Delete By Value\n");
        printf("6. Search Value\n");
        printf("7. Display List\n");
        printf("8. Reverse List\n");
        printf("9. Sort List\n");
        printf("0. Back\n");

        printf("Choice : ");
        scanf("%d", &choice);

        switch(choice) {

            case 1:

                printf("Enter value : ");
                scanf("%d", &value);

                insertBeginning(&L, value);

                break;

            case 2:

                printf("Enter value : ");
                scanf("%d", &value);

                insertEnd(&L, value);

                break;

            case 3:

                value = deleteBeginning(&L);

                if(value != -1) {
                    printf("Deleted : %d\n", value);
                } else {
                    printf("List is empty\n");
                }

                break;

            case 4:

                value = deleteEnd(&L);

                if(value != -1) {
                    printf("Deleted : %d\n", value);
                } else {
                    printf("List is empty\n");
                }

                break;

            case 5:

                printf("Enter value : ");
                scanf("%d", &value);

                if(deleteByValue(&L, value) != -1) {
                    printf("Value deleted\n");
                } else {
                    printf("Value not found\n");
                }

                break;

            case 6:

                printf("Enter value : ");
                scanf("%d", &value);

                if(searchValue(&L, value) != NULL) {
                    printf("Value found\n");
                } else {
                    printf("Value not found\n");
                }

                break;

            case 7:

                displayList(&L);

                break;

            case 8:

                reverseList(&L);

                printf("List reversed successfully\n");

                break;

            case 9:

                sortListBubble(&L);

                printf("List sorted successfully\n");

                break;

            case 0:

                printf("Returning...\n");

                break;

            default:

                printf("Invalid choice\n");
        }

    } while(choice != 0);
}

void stringMenu() {

    int choice;

    char str1[100];
    char str2[100];

    do {

        printf("\n=== STRING MENU ===\n");

        printf("1. String Length\n");
        printf("2. Copy String\n");
        printf("0. Back\n");

        printf("Choice : ");
        scanf("%d", &choice);

        switch(choice) {

            case 1:

                printf("Enter string : ");
                scanf("%s", str1);

                printf("Length = %d\n", my_strlen(str1));

                break;

            case 2:

                printf("Enter source string : ");
                scanf("%s", str1);

                my_strcpy(str2, str1);

                printf("Copied string : %s\n", str2);

                break;

            case 0:

                printf("Returning...\n");

                break;

            default:

                printf("Invalid choice\n");
        }

    } while(choice != 0);
}

void fileMenu() {

    int choice;

    Record r;

    char filename[100];

    do {

        printf("\n=== FILE MENU ===\n");

        printf("1. Create Binary File\n");
        printf("2. Write Record\n");
        printf("0. Back\n");

        printf("Choice : ");
        scanf("%d", &choice);

        switch(choice) {

            case 1:

                printf("Enter filename : ");
                scanf("%s", filename);

                if(createBinaryFile(filename) == 0) {
                    printf("File created successfully\n");
                } else {
                    printf("Failed to create file\n");
                }

                break;

            case 2:

                printf("Enter filename : ");
                scanf("%s", filename);

                printf("Enter id : ");
                scanf("%d", &r.id);

                printf("Enter name : ");
                scanf("%s", r.name);

                printf("Enter score : ");
                scanf("%f", &r.score);

                printf("Enter category : ");
                scanf("%s", r.category);

                if(writeRecord(filename, &r) == 0) {
                    printf("Record written successfully\n");
                } else {
                    printf("Failed to write record\n");
                }

                break;

            case 0:

                printf("Returning...\n");

                break;

            default:

                printf("Invalid choice\n");
        }

    } while(choice != 0);
}

int main() {

    int choice;

    do {

        printf("\n========== ADS2 PROJECT DEMO ==========\n");

        printf("1. Arrays\n");
        printf("2. Linked Lists\n");
        printf("3. File Handling\n");
        printf("4. String Utilities\n");
        printf("0. Exit\n");

        printf("Choice : ");
        scanf("%d", &choice);

        switch(choice) {

            case 1:

                arrayMenu();

                break;

            case 2:

                linkedListMenu();

                break;

            case 3:

                fileMenu();

                break;

            case 4:

                stringMenu();

                break;

            case 0:

                printf("Exiting program...\n");

                break;

            default:

                printf("Invalid choice\n");
        }

    } while(choice != 0);

    return 0;
}